<?php

/**
 * @file
 * Definition of Drupal\Core\Entity\StringStorageException.
 */

/**
 * Defines an exception thrown when storage operations fail.
 */
class StringStorageException extends \Exception { }
